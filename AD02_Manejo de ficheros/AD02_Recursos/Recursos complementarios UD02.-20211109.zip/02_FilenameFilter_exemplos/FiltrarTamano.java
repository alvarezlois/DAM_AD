import java.io.File;
import java.io.FilenameFilter; 
import java.util.Scanner;

public class FiltrarTamano implements FilenameFilter {
    
    float tamano;
    
    FiltrarTamano(float tamano){
        this.tamano = tamano;
    }
           
    public boolean accept(File directorio, String nome){
        File ficheiro = new File(directorio,nome);
        return ficheiro.length() > this.tamano;
    }
    
    public static void main(String[] args) {
        System.out.printf("Introduce unha ruta:");
        Scanner consola = new Scanner(System.in);
        String ruta = consola.nextLine();
        try {
            File ficheiro = new File(ruta);
            // Filtraremos os ficheiros menores de 1MB
            String[] listaFiltrada = ficheiro.list(new FiltrarTamano(1024*1024));
            for(int i = 0; i < listaFiltrada.length; i++)
            System.out.println(listaFiltrada[i]);
        } catch (Exception ex) {
            System.out.println("Erro ó procurar en en: " + ruta); 
        }
        }
}