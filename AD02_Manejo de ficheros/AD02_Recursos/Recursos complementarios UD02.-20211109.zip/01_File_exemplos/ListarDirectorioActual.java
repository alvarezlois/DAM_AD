/*
 * Código Java que exercita a clase File para amosar o contido dun directorio
 * e indicar para cada elemento se é un ficheiro ou un directorio.
 * Este código utiliza os métodos seguintes da clase File:
 *   - listFiles
 *   - getName
 *   - isFile
 *   - isDirectory
 */

//Importa as utilidades de entrada/saida de Java
import java.io.*;

public class ListarDirectorioActual {
	public static void main(String[] args) {
		// Variable cadena coa ruta do directorio actual
		String rutaDirectorio = ".";
		// Instancia un obxecto da clase File sobre a ruta do directorio
		File directorio = new File(rutaDirectorio);
		// Crea unha lista de obxectos File a partir do contido do directorio
		File[] contidoDirectorio = directorio.listFiles();
		// Imprime por pantalla o numero de ficheiros no directorio
		System.out.printf("Ficheiros no directorio actual: %d %n", contidoDirectorio.length);
		// Recorre o contido do directorio e para cada un indica se e ficheiro o directorio
		for (int i = 0; i < contidoDirectorio.length; i++) {
			File elemento = contidoDirectorio[i];
			System.out.printf(" - %s ", elemento.getName());
                        if(elemento.isFile()) System.out.println("(Ficheiro)"); 
                        else if(elemento.isDirectory()) System.out.println("(Directorio)"); 
		}
	}
}
