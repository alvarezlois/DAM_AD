/*
 * C�digo Java que exercita a clase File para amosar a informaci�n
 * dun ficheiro dada a sua ruta.
 * Este c�digo utiliza os m�todos seguintes da clase File:
 *   - getName
 *   - getPath
 *   - getAbsolutePath
 *   - canRead
 *   - canWrite
 *   - length
 *   - isDirectory
 *   - isFile
 */

// Importa as utilidades de entrada/saida de Java
import java.io.*;
// Importa a clase Scanner para ler por consola
import java.util.Scanner;

public class InfoFicheiro {
    public static void main(String[] args) {
        System.out.printf("Introduce unha ruta de ficheiro:");
        Scanner consola = new Scanner(System.in);
        String ruta = consola.nextLine();
        System.out.println("Informaci�n sobre o ficheiro:");
        File f = new File(ruta);  
        if(f.exists()){
            System.out.println("Nome:                 " + f.getName());
            System.out.println("Ruta:                 " + f.getPath());
            System.out.println("Ruta absoluta:        " + f.getAbsolutePath());
            System.out.println("Permiso de lectura:   " + f.canRead());
            System.out.println("Permiso de escritura: " + f.canWrite());
            System.out.println("Tama�o:               " + f.length());
            System.out.println("� un directorio:      " + f.isDirectory()); 
            System.out.println("� un ficheiro:        " + f.isFile());
      }
    }
}

